/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 28, 2021 9:33:06 PM
 */

package c209_gradedPart2.Final;

public class STCGuest extends Guest{

	private String discountCode;
	private String discountDesctiption;
	private int groupSize;
	private int discountRate;
	private String discountType;

	public STCGuest(int bookingId, int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice,
			int contactNumber, int noOfDays, String discountCode, String discountDesctiption, int groupSize,
			int discountRate, String discountType) {
		super(bookingId, guestId, guestName, guestRoomNo, guestType, dailyPrice, contactNumber, noOfDays);
		this.discountCode = discountCode;
		this.discountDesctiption = discountDesctiption;
		this.groupSize = groupSize;
		this.discountRate = discountRate;
		this.discountType = discountType;
	}

	public String getDiscountCode() {
		return discountCode;
	}
	
	public String getDiscountDesctiption() {
		return discountDesctiption;
	}

	public int getGroupSize() {
		return groupSize;
	}

	public int getDiscountRate() {
		return discountRate;
	}

	public String getDiscountType() {
		return discountType;
	}

	public double calculateHotelStayFee(int dailyPrice) {
		double cost = 0;
		if (discountType.equals("Fixed")) {
			cost = (dailyPrice * noOfDays) - (discountRate * noOfDays);
		}
		else if (discountType.equals("Percentage")) {
			cost = (dailyPrice * noOfDays) * ((100.00 - discountRate)/100.00);
		}
		return cost;
	}
}
