/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 3, 2021 8:46:59 AM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_DeleteBookings extends Application {

	private BorderPane pane = new BorderPane();
	private HBox topHPane = new HBox();
	private VBox topVPane = new VBox();
	private HBox bottomHPane1 = new HBox();
	private HBox bottomHPane2 = new HBox();
	private Label labelBookingID = new Label("Booking ID:");
	private TextField textfieldBookingID = new TextField();
	private TextArea textareaGuestBookings = new TextArea();
	private Label lbOutput = new Label();
	private VBox bottomVPane = new VBox();
	private Button btDelete = new Button("Delete");
	private Button btConfirmDelete = new Button("Confirm Delete");
	private Button btCancel = new Button("Cancel");
	private static final String patternForBookingID = "\\d+";
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	
	public void start(Stage primaryStage) {
		
		textareaGuestBookings.setStyle("-fx-font-family: monospace");
		btDelete.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btDelete.setTextFill(Color.WHITE);
		btDelete.setStyle("-fx-background-color: BLUE");
		btConfirmDelete.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btConfirmDelete.setTextFill(Color.WHITE);
		btConfirmDelete.setStyle("-fx-background-color: BLUE");
		btCancel.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btCancel.setTextFill(Color.WHITE);
		btCancel.setStyle("-fx-background-color: RED");
		
		btConfirmDelete.setDisable(true);
		btCancel.setDisable(true);
		
		textfieldBookingID.setPrefColumnCount(10);
		
		topHPane.getChildren().addAll(labelBookingID, textfieldBookingID);

		EventHandler<ActionEvent> handleFind = (ActionEvent e) -> doFind();
		btDelete.setOnAction(handleFind);
		
		EventHandler<ActionEvent> handleUpdate = (ActionEvent e) -> doDelete();
		btConfirmDelete.setOnAction(handleUpdate);
		
		EventHandler<ActionEvent> handleCancel = (ActionEvent e) -> doCancel();
		btCancel.setOnAction(handleCancel);
		
		bottomHPane1.getChildren().addAll(btConfirmDelete, btCancel);
		bottomHPane1.setSpacing(10);
		bottomHPane2.getChildren().add(lbOutput);
		bottomVPane.getChildren().addAll(bottomHPane1, bottomHPane2);
		topVPane.getChildren().addAll(topHPane, btDelete);

		topHPane.setSpacing(10);
		topHPane.setAlignment(Pos.CENTER);
		topVPane.setAlignment(Pos.CENTER);
		pane.setTop(topVPane);
		topVPane.setSpacing(10);
		bottomHPane1.setAlignment(Pos.CENTER);
		bottomHPane2.setAlignment(Pos.CENTER);
		pane.setCenter(textareaGuestBookings);
		bottomVPane.setAlignment(Pos.CENTER);
		bottomVPane.setSpacing(10);
		pane.setBottom(bottomVPane);
		BorderPane.setAlignment(topVPane, Pos.CENTER);
		BorderPane.setAlignment(textareaGuestBookings, Pos.CENTER);
		BorderPane.setAlignment(bottomVPane, Pos.CENTER);
		
		textareaGuestBookings.setEditable(false);
		topVPane.setPadding(new Insets(10,10,10,10));
		bottomVPane.setPadding(new Insets(10,10,10,10));
		Scene mainScene = new Scene(pane);
		
		pane.setPadding(new Insets(10,10,10,10));
		primaryStage.setTitle("Delete Guest Booking");
		primaryStage.setWidth(1100);
		primaryStage.setHeight(400);
		primaryStage.setScene(mainScene);
		primaryStage.show();

	}
	
	private void doCancel() {
		textareaGuestBookings.setText("");
		textfieldBookingID.setText("");
		btCancel.setDisable(true);
		btConfirmDelete.setDisable(true);
		textareaGuestBookings.setEditable(false);
	}
	
	private void doDelete() {
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);
		
		if (textfieldBookingID.getText().equals("")) {
			lbOutput.setText("Please fill in the booking ID text field.");
		}
		else if (!Pattern.matches(patternForBookingID, textfieldBookingID.getText())) {
			textareaGuestBookings.setText("Invalid Booking ID!");
		}
		
		else {
			
			String updateSQL = "DELETE FROM hotel_bookings WHERE BookingID=" + Integer.parseInt(textfieldBookingID.getText());
			int rowsUpdated = DBUtil.execSQL(updateSQL);

			if (rowsUpdated == 1) {
				lbOutput.setText("Booking successfully deleted!");
			} else {
				lbOutput.setText("Deletion failed!");
			}
		}
		
	}
	
	private void doFind() {
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);

		if (textfieldBookingID.getText().equals("")) {
			textareaGuestBookings.setText("Please input a Booking ID in the text field above.");
		}
		else if (!Pattern.matches(patternForBookingID, textfieldBookingID.getText())) {
			textareaGuestBookings.setText("Invalid Booking ID!");
		}
		else {
			//String selectSQL = "SELECT h.*, s.Description FROM hotel_bookings h WHERE h.BookingID=" + Integer.parseInt(textfieldBookingID.getText()) + " INNER JOIN stay_types s ON s.StayType = h.GuestType";
			String selectSQL = "SELECT h.*, s.Description, DATEDIFF(h.CheckOut, h.CheckIn) FROM hotel_bookings h INNER JOIN stay_types s ON s.StayType = h.GuestType WHERE h.BookingID=" + Integer.parseInt(textfieldBookingID.getText());
			ResultSet rs = DBUtil.getTable(selectSQL);
			textareaGuestBookings.setText(String.format("%-12s %-10s %-11s %-18s %-15s %-12s %-20s %-15s %-16s\n", "Booking ID", "Guest ID", "Room Number", "Guest Type", "Discount Code", "Group Size", "Stay Period (Days)", "Check-in Date", "Check-out Date"));
			try {
				int counter = 0;
				while(rs.next()) {
					counter += 1;
					int guestID = rs.getInt("h.GuestID");
					String room = rs.getString("h.RoomNo");
					String guestType = rs.getString("s.Description");
					String discountCode = rs.getString("h.DiscountCode");
					String groupSize = rs.getString("h.GroupSize");
					String noOfDays = rs.getString("DATEDIFF(h.CheckOut, h.CheckIn)");
					String checkIn = rs.getString("h.CheckIn");
					String checkOut = rs.getString("h.CheckOut");
					
					textareaGuestBookings.appendText(String.format("%-12s %-10s %-11s %-18s %-15s %-12s %-20s %-15s %-16s\n", textfieldBookingID.getText(), String.valueOf(guestID), room, guestType, discountCode, groupSize, String.valueOf(noOfDays), checkIn, checkOut));
					
					btConfirmDelete.setDisable(false);
					btCancel.setDisable(false);
				}
				int noOfRows = rs.getRow();
				if (counter == noOfRows) {
					textareaGuestBookings.setText("This booking ID does not exist!");
					btConfirmDelete.setDisable(true);
					btCancel.setDisable(true);
				}
			}
			catch (SQLException e) {
				e.getMessage();
			}
			
			DBUtil.close();
		}

	}
}