/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 3, 2021 8:28:44 AM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_AddGuest extends Application {

	private VBox pane = new VBox();
	private HBox row1 = new HBox();
	private HBox row2 = new HBox();
	private HBox row3 = new HBox();
	private HBox row4 = new HBox();
	private HBox row5 = new HBox();
	private int positioning = 0;
	private Label labelName = new Label("Name: ");
	private Label labelTravelDoc = new Label("Travel Document: ");
	private Label labelOutput = new Label();
	private Label labelMobile = new Label("Mobile Number: ");
	private Label labelNotifyTravelDocID = new Label("*Note: Accepted travel documents: TD01 (Singaporean), TD02 (Singapore PR), TD03 (Employment Pass), TD04 (Work Permit), TD05 (Student pass).\n");
	private Label labelNotifyMobileNumber = new Label("*Note: Only Singapore mobile numbers are accepted. Do not leave spacings.\n");
	private TextField textfieldName = new TextField();
	private TextField textfieldTravelDoc = new TextField();
	private TextField textfieldMobile = new TextField();
	private Button buttonAdd = new Button("Add Guest");
	private static final String patternForName = "^[a-zA-z ]*$";
	private static final String patternForMobileNumber = "[89]\\d{7}";
	private static final int LABEL_PREFWIDTH = 100;
	private static final int TEXTFIELD_COLUMNCOUNT = 15;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	
	public void start(Stage primaryStage) {

		buttonAdd.setFont(Font.font("Arial",FontWeight.BOLD,12));
		buttonAdd.setTextFill(Color.WHITE);
		buttonAdd.setStyle("-fx-background-color: BLUE");
		
		labelName.setPrefWidth(LABEL_PREFWIDTH);
		labelTravelDoc.setPrefWidth(LABEL_PREFWIDTH);
		labelMobile.setPrefWidth(LABEL_PREFWIDTH);
		
		textfieldName.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		textfieldTravelDoc.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		textfieldMobile.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);

		EventHandler<ActionEvent> handleInsert = (ActionEvent e) -> doInsertGuest();
		
		buttonAdd.setOnAction(handleInsert);
		
		labelNotifyTravelDocID.setFont(Font.font("Arial",8));
		labelNotifyTravelDocID.setTextFill(Color.RED);
		labelNotifyTravelDocID.setAlignment(Pos.CENTER);
		labelNotifyMobileNumber.setFont(Font.font("Arial",8));
		labelNotifyMobileNumber.setTextFill(Color.RED);
		
		row1.getChildren().addAll(labelName,textfieldName);
		row1.setAlignment(Pos.CENTER);
		row2.getChildren().addAll(labelTravelDoc,textfieldTravelDoc);
		row2.setAlignment(Pos.CENTER);
		row3.getChildren().addAll(labelNotifyTravelDocID);
		row3.setAlignment(Pos.CENTER);
		row4.getChildren().addAll(labelMobile,textfieldMobile);
		row4.setAlignment(Pos.CENTER);
		row5.getChildren().addAll(labelNotifyMobileNumber);
		row5.setAlignment(Pos.CENTER);
		pane.getChildren().addAll(row1,row2,row3,row4,row5,buttonAdd,labelOutput);

		pane.setAlignment(Pos.TOP_CENTER);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setSpacing(10);
		Scene mainScene = new Scene(pane);
		
		primaryStage.setTitle("Add New Guest");
		primaryStage.setWidth(600);
		primaryStage.setHeight(300);
		primaryStage.setScene(mainScene);
		primaryStage.show();
	}

	public void doInsertGuest() {

		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);

		if (textfieldName.getText().equals("") || textfieldTravelDoc.getText().equals("") || textfieldMobile.getText().equals("")){
			labelOutput.setText("Please fill in all fields!");
		}
		else if (!Pattern.matches(patternForName, textfieldName.getText())) {
			labelOutput.setText("Invalid name, guest not added!");
		}
		else if (!Pattern.matches(patternForMobileNumber, textfieldMobile.getText())) {
			labelOutput.setText("Invalid mobile number, guest not added!");
		}
		else {
			ResultSet rs = DBUtil.getTable("SELECT * FROM guests");
			ResultSet rsCheckingTravelDocIDExists = DBUtil.getTable("SELECT ID FROM travel_docs WHERE ID='" + textfieldTravelDoc.getText() + "'");
			
			try {
				if(!rsCheckingTravelDocIDExists.next()) {
					labelOutput.setText("This travel document does not exist, guest not added!");
				}
				else {
					while (rs.next()) {
					}
					rs.last();
					positioning = rs.getRow();
					String insertSQL = String.format("INSERT INTO guests(GuestID, GuestName, TravelDocID, ContactNumber) VALUES ('%d', '%s', '%s', %d)",
							positioning+1, textfieldName.getText(), textfieldTravelDoc.getText(), Integer.parseInt(textfieldMobile.getText()));
					int rowsAffected = DBUtil.execSQL(insertSQL);

					if (rowsAffected == 1) {
						labelOutput.setText("Guest added!");
					} else {
						labelOutput.setText("Failed to add guest!");
					}
				}
					
			} catch (SQLException e){
				labelOutput.setText("Failed to add guest!");
			}
			
		}
		DBUtil.close();
	}

}
