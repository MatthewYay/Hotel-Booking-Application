/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 3, 2021 8:43:32 AM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_UpdateBookings extends Application {

	private BorderPane pane = new BorderPane();
	private HBox topHPane = new HBox();
	private VBox topVPane = new VBox();
	private HBox bottomHPane1 = new HBox();
	private HBox bottomHPane2 = new HBox();
	private HBox bottomHPane3 = new HBox();
	private HBox bottomHPane4 = new HBox();
	private Label labelBookingID = new Label("Booking ID:");
	private TextField textfieldBookingID = new TextField();
	private Label lbUpdatedCheckInDate = new Label("Updated Check-in Date: ");
	private DatePicker tfUpdatedCheckInDate = new DatePicker();
	private Label lbUpdatedCheckOutDate = new Label("Updated Check-out Date: ");
	private DatePicker tfUpdatedCheckOutDate = new DatePicker();
	private TextArea textareaGuestBookings = new TextArea();
	private Label lbOutput = new Label();
	private Label labelCheckInDate = new Label();
	private Label labelCheckOutDate = new Label();
	private VBox bottomVPane = new VBox();
	private Button btFind = new Button("Search");
	private Button btEdit = new Button("Update");
	private static final String patternForBookingID = "\\d+";
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	
	public void start(Stage primaryStage) {
		
		textareaGuestBookings.setStyle("-fx-font-family: monospace");
		btFind.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btFind.setTextFill(Color.WHITE);
		btFind.setStyle("-fx-background-color: BLUE");
		btEdit.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btEdit.setTextFill(Color.WHITE);
		btEdit.setStyle("-fx-background-color: BLUE");
		
		btEdit.setDisable(true);
		tfUpdatedCheckInDate.setDisable(true);
		tfUpdatedCheckOutDate.setDisable(true);
		
		textfieldBookingID.setPrefColumnCount(10);
		
		topHPane.getChildren().addAll(labelBookingID, textfieldBookingID);

		EventHandler<ActionEvent> handleFind = (ActionEvent e) -> doFind();
		btFind.setOnAction(handleFind);
		
		EventHandler<ActionEvent> handleUpdate = (ActionEvent e) -> doEdit();
		btEdit.setOnAction(handleUpdate);
		
		EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                LocalDate i = tfUpdatedCheckInDate.getValue();
                labelCheckInDate.setText(i.toString());
            }
        };
        tfUpdatedCheckInDate.setShowWeekNumbers(true);
        tfUpdatedCheckInDate.setOnAction(event);
        
        EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                LocalDate ld = tfUpdatedCheckOutDate.getValue();
                labelCheckOutDate.setText(ld.toString());
            }
        };
        tfUpdatedCheckOutDate.setShowWeekNumbers(true);
        tfUpdatedCheckOutDate.setOnAction(event2);
		
		bottomHPane1.getChildren().addAll(lbUpdatedCheckInDate, tfUpdatedCheckInDate);
		bottomHPane2.getChildren().addAll(lbUpdatedCheckOutDate, tfUpdatedCheckOutDate);
		bottomHPane3.getChildren().add(btEdit);
		bottomHPane4.getChildren().add(lbOutput);
		bottomVPane.getChildren().addAll(bottomHPane1, bottomHPane2, bottomHPane3, bottomHPane4);
		topVPane.getChildren().addAll(topHPane, btFind);

		topHPane.setSpacing(10);
		topHPane.setAlignment(Pos.CENTER);
		topVPane.setAlignment(Pos.CENTER);
		pane.setTop(topVPane);
		topVPane.setSpacing(10);
		
		bottomHPane1.setAlignment(Pos.CENTER);
		bottomHPane2.setAlignment(Pos.CENTER);
		bottomHPane3.setAlignment(Pos.CENTER);
		bottomHPane4.setAlignment(Pos.CENTER);
		pane.setCenter(textareaGuestBookings);
		bottomVPane.setAlignment(Pos.CENTER);
		bottomVPane.setSpacing(10);
		pane.setBottom(bottomVPane);
		
		BorderPane.setAlignment(topVPane, Pos.CENTER);
		BorderPane.setAlignment(textareaGuestBookings, Pos.CENTER);
		BorderPane.setAlignment(bottomVPane, Pos.CENTER);
		
		textareaGuestBookings.setEditable(false);
		topVPane.setPadding(new Insets(10,10,10,10));
		bottomVPane.setPadding(new Insets(10,10,10,10));
		Scene mainScene = new Scene(pane);
		
		pane.setPadding(new Insets(10,10,10,10));
		primaryStage.setTitle("Update Guest Booking Stay Period");
		primaryStage.setWidth(1100);
		primaryStage.setHeight(400);
		primaryStage.setScene(mainScene);
		primaryStage.show();

	}
	
	private void doEdit() {
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);
		
		if (textfieldBookingID.getText().equals("") || labelCheckOutDate.getText().equals("") || labelCheckInDate.getText().equals("")) {
			lbOutput.setText("Please fill in all fields.");
		}
		else if (!Pattern.matches(patternForBookingID, textfieldBookingID.getText())) {
			textareaGuestBookings.setText("Invalid Booking ID!");
		}
		
		else {
			
			String updateSQL = "UPDATE hotel_bookings SET CheckIn='" + labelCheckInDate.getText() + "', CheckOut='" + labelCheckOutDate.getText() + "' WHERE BookingID=" + textfieldBookingID.getText() + "";
			int rowsUpdated = DBUtil.execSQL(updateSQL);

			if (rowsUpdated == 1) {
				lbOutput.setText("Booking stay information updated!");
			} else {
				lbOutput.setText("Updating failed!");
			}
		}
		
	}
	
	private void doFind() {
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);

		if (textfieldBookingID.getText().equals("")) {
			textareaGuestBookings.setText("Please input a Booking ID in the text field above.");
		}
		else if (!Pattern.matches(patternForBookingID, textfieldBookingID.getText())) {
			textareaGuestBookings.setText("Invalid Booking ID!");
		}
		else {
			String selectSQL = "SELECT h.*, s.Description, DATEDIFF(h.CheckOut, h.CheckIn) FROM hotel_bookings h INNER JOIN stay_types s ON s.StayType = h.GuestType WHERE h.BookingID=" + Integer.parseInt(textfieldBookingID.getText());
			ResultSet rs = DBUtil.getTable(selectSQL);
			textareaGuestBookings.setText(String.format("%-12s %-10s %-11s %-18s %-15s %-12s %-20s %-15s %-16s\n", "Booking ID", "Guest ID", "Room Number", "Guest Type", "Discount Code", "Group Size", "Stay Period (Days)", "Check-in Date", "Check-out Date"));
			try {
				int counter = 0;
				while(rs.next()) {
					counter += 1;
					int guestID = rs.getInt("h.GuestID");
					String room = rs.getString("h.RoomNo");
					String guestType = rs.getString("s.Description");
					String discountCode = rs.getString("h.DiscountCode");
					String groupSize = rs.getString("h.GroupSize");
					String noOfDays = rs.getString("DATEDIFF(h.CheckOut, h.CheckIn)");
					String checkIn = rs.getString("h.CheckIn");
					String checkOut = rs.getString("h.CheckOut");
					
					textareaGuestBookings.appendText(String.format("%-12s %-10s %-11s %-18s %-15s %-12s %-20s %-15s %-16s\n", textfieldBookingID.getText(), String.valueOf(guestID), room, guestType, discountCode, groupSize, String.valueOf(noOfDays), checkIn, checkOut));
					
					btEdit.setDisable(false);
					tfUpdatedCheckInDate.setDisable(false);
					tfUpdatedCheckOutDate.setDisable(false);
					
				}
				int noOfRows = rs.getRow();
				if (counter == noOfRows) {
					textareaGuestBookings.setText("This booking ID does not exist!");
					btEdit.setDisable(true);
				}
			}
			catch (SQLException e) {
				e.getMessage();
			}
			
			DBUtil.close();
		}

	}

}
