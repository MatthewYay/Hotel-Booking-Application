/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 28, 2021 9:38:57 PM
 */

package c209_gradedPart2.Final;

public abstract class Guest {

	private int bookingId;
	private int guestId;
	private String guestName;
	private String guestRoomNo;
	private String guestType;
	private int dailyPrice;
	private int contactNumber;
	protected int noOfDays;
	
	public Guest(int bookingId, int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice,
			int contactNumber, int noOfDays) {
		this.bookingId = bookingId;
		this.guestId = guestId;
		this.guestName = guestName;
		this.guestRoomNo = guestRoomNo;
		this.guestType = guestType;
		this.dailyPrice = dailyPrice;
		this.contactNumber = contactNumber;
		this.noOfDays = noOfDays;
	}

	public int getBookingId() {
		return bookingId;
	}

	public int getGuestId() {
		return guestId;
	}

	public String getGuestName() {
		return guestName;
	}

	public String getGuestRoomNo() {
		return guestRoomNo;
	}

	public String getGuestType() {
		return guestType;
	}

	public int getDailyPrice() {
		return dailyPrice;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public abstract double calculateHotelStayFee(int dailyPrice);
	
}
