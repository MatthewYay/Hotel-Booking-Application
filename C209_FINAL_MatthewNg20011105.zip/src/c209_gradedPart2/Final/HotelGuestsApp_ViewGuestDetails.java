/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 3, 2021 8:49:37 AM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_ViewGuestDetails extends Application {

	private BorderPane pane = new BorderPane();
	private HBox topHPane = new HBox();
	private VBox topVPane = new VBox();
	private HBox topHPane2 = new HBox();
	private HBox bottomPane = new HBox();
	private ToggleGroup tg = new ToggleGroup();
	private Label lbRadioBtChoice = new Label("Choose a guest type to view:\n\n");
    private RadioButton r1 = new RadioButton("Stay-home-notice (SHN) Guests");
    private RadioButton r2 = new RadioButton("Staycation (STC) Guests");
    private RadioButton r3 = new RadioButton("All Guests");
	private TextArea textareaViewGuest = new TextArea();
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	private ArrayList<Guest> guestsList = new ArrayList<Guest>();
	
	public void start(Stage primaryStage) {

		loadingGuests();
		
		textareaViewGuest.setStyle("-fx-font-family: monospace");
		r1.setToggleGroup(tg);
        r2.setToggleGroup(tg);
        r3.setToggleGroup(tg);
  
        tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>() 
        {
            public void changed(ObservableValue<? extends Toggle> ob, 
                                                    Toggle o, Toggle n)
            {
  
                RadioButton rb = (RadioButton)tg.getSelectedToggle();
  
                if (rb != null) {
                    if (rb.getText().equals("All Guests")) {
                    	doViewAll();
                    }
                    else if (rb.getText().equals("Stay-home-notice (SHN) Guests")) {
                    	doViewSHN();
                    }
                    else if (rb.getText().equals("Staycation (STC) Guests")) {
                    	doViewSTC();
                    }
  
                }
            }
        });
		
        lbRadioBtChoice.setFont(Font.font("Verdana",FontWeight.BOLD,15));
		lbRadioBtChoice.setTextFill(Color.BLUE);
		textareaViewGuest.setEditable(false);
		topHPane.getChildren().addAll(lbRadioBtChoice);
		topHPane2.getChildren().addAll(r3, r1, r2);
		topHPane2.setSpacing(100);
		topHPane2.setAlignment(Pos.CENTER);
		topHPane2.setPadding(new Insets(10,10,10,10));
		
		bottomPane.getChildren().addAll(textareaViewGuest);
		topVPane.getChildren().addAll(topHPane, topHPane2);
		topHPane.setSpacing(10);
		topHPane.setAlignment(Pos.CENTER);
		topVPane.setAlignment(Pos.CENTER);
		pane.setTop(topVPane);
		topVPane.setSpacing(10);
		pane.setCenter(textareaViewGuest);
		bottomPane.setAlignment(Pos.CENTER);
		bottomPane.setSpacing(10);
		pane.setBottom(bottomPane);
		BorderPane.setAlignment(topVPane, Pos.CENTER);
		BorderPane.setAlignment(textareaViewGuest, Pos.CENTER);
		BorderPane.setAlignment(bottomPane, Pos.CENTER);
		
		pane.setPadding(new Insets(10,10,10,10));
		Scene mainScene = new Scene(pane);
		primaryStage.setTitle("View Guest Bookings");
		primaryStage.setWidth(1100);
		primaryStage.setHeight(300);
		primaryStage.setScene(mainScene);
		primaryStage.show();
		
	}

	private void loadingGuests() {
		
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);

		String selectSQL = "SELECT g.*, hb.*, hr.*, hd.*, td.*, st.Description, DATEDIFF(hb.CheckOut, hb.CheckIn) FROM hotel_bookings hb LEFT JOIN guests g ON g.GuestID = hb.GuestID INNER JOIN stay_types st ON st.StayType = hb.GuestType LEFT JOIN travel_docs td ON td.ID = g.TravelDocID INNER JOIN hotel_room hr ON hr.RoomNo = hb.RoomNo LEFT JOIN hotel_discounts hd ON hd.DiscountCode = hb.DiscountCode";
		ResultSet rs = DBUtil.getTable(selectSQL);
			
		try {
			while(rs.next()) {
				int bookingId = rs.getInt("hb.BookingID");
				int guestId = rs.getInt("hb.GuestID");
				String guestName = rs.getString("g.GuestName");
				String guestRoomNo = rs.getString("hb.RoomNo");
				String guestType = rs.getString("st.Description");
				int dailyPrice = rs.getInt("hr.DailyPrice");
				int contactNumber = rs.getInt("g.ContactNumber");
				int noOfDays = rs.getInt("DATEDIFF(hb.CheckOut, hb.CheckIn)");
				String discountCode = rs.getString("hb.DiscountCode");
				String discountDescription = rs.getString("hd.Description");
				int groupSize = rs.getInt("hb.GroupSize");
				int discountRate = rs.getInt("hd.Rate");
				String discountType = rs.getString("hd.DiscountType");
				String travelDocType = rs.getString("td.Description");
				
				if (guestType.equals("Stay-Home-Notice")) {
					Guest newShnGuest = new SHNGuest(bookingId, guestId, guestName, guestRoomNo, guestType, dailyPrice, contactNumber, noOfDays, travelDocType);
					guestsList.add(newShnGuest);
				}
				
				else if(guestType.equals("Staycation")) {
					Guest newStcGuest = new STCGuest(bookingId, guestId, guestName, guestRoomNo, guestType, dailyPrice, contactNumber, noOfDays, discountCode, discountDescription, groupSize, discountRate, discountType);
					guestsList.add(newStcGuest);
				}

			}
				
		}
		catch (SQLException e) {
			e.getMessage();
		}
			
		DBUtil.close();
		
		
	}

	private void doViewAll() {
		textareaViewGuest.setText(String.format("%-12s %-10s %-20s %-13s %-18s %-16s %-15s %-15s\n", "Booking ID", "Guest ID", "Guest Name", "Room Number", "Guest Type", "Contact Number", "No. of Days", "Total Fee ($)"));
		for (Guest g : guestsList) {
			textareaViewGuest.appendText(String.format("%-12d %-10d %-20s %-13s %-18s %-16d %-15d %-15.2f\n", g.getBookingId(), g.getGuestId(), g.getGuestName(), g.getGuestRoomNo(), g.getGuestType(), g.getContactNumber(), g.getNoOfDays(), g.calculateHotelStayFee(g.getDailyPrice())));
		}
		
	}

	private void doViewSHN() {
		textareaViewGuest.setText(String.format("%-12s %-10s %-20s %-13s %-18s %-16s %-15s %-18s %-15s\n", "Booking ID", "Guest ID", "Guest Name", "Room Number", "Guest Type", "Contact Number", "No. of Days", "Travel Document", "Total Fee ($)"));
		
		for (Guest g : guestsList) {
			if (g instanceof SHNGuest) {
				textareaViewGuest.appendText(String.format("%-12d %-10d %-20s %-13s %-18s %-16d %-15d %-18s %-15.2f\n", g.getBookingId(), g.getGuestId(), g.getGuestName(), g.getGuestRoomNo(), g.getGuestType(), g.getContactNumber(), g.getNoOfDays(), ((SHNGuest) g).getTravelDocType(), g.calculateHotelStayFee(g.getDailyPrice())));
			}
		}
	}
	
	private void doViewSTC() {
		textareaViewGuest.setText(String.format("%-12s %-10s %-20s %-13s %-18s %-16s %-15s %-12s %-15s %-22s %-15s\n", "Booking ID", "Guest ID", "Guest Name", "Room Number", "Guest Type", "Contact Number", "No. of Days", "Group Size", "Discount Code", "Discount Description", "Total Fee ($)"));
		
		for (Guest g : guestsList) {
			if (g instanceof STCGuest) {
				textareaViewGuest.appendText(String.format("%-12d %-10d %-20s %-13s %-18s %-16d %-15d %-12d %-15s %-22s %-15.2f\n", g.getBookingId(), g.getGuestId(), g.getGuestName(), g.getGuestRoomNo(), g.getGuestType(), g.getContactNumber(), g.getNoOfDays(), ((STCGuest) g).getGroupSize(), ((STCGuest) g).getDiscountCode(), ((STCGuest) g).getDiscountDesctiption(), g.calculateHotelStayFee(g.getDailyPrice())));
				
			}
		}
	}

}
