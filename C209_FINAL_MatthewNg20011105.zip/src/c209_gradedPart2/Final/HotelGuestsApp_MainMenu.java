/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 2, 2021 1:42:14 PM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_MainMenu extends Application{
	
	Label labelTitle = new Label("Kingston Hotel");
	Label labelWelcome = new Label();
	Label labelChoose = new Label("Choose an option:\n\n\n");
	Button btnAddGuest = new Button("Add Guest");
	Button btnUpdateBookings = new Button("Update Guest Booking Stay Period");
	Button btnDeleteBookings = new Button("Delete Guest Booking");
	Button btnViewGuestDetails = new Button("View Guest Bookings");
	Button btnAddBookings = new Button("Add Room Booking");
	private static final int BUTTON_PREFWIDTH = 250;
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	
	public void start(Stage primaryStage) throws Exception {
		
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);
		
		if (HotelGuestsApp_Loginpage.checker == false) {
			HotelGuestsApp_Loginpage.unstarPasswordField.setText(HotelGuestsApp_Loginpage.passwordField.getText());
		}
		else if (HotelGuestsApp_Loginpage.checker == true) {
			HotelGuestsApp_Loginpage.passwordField.setText(HotelGuestsApp_Loginpage.unstarPasswordField.getText());
		}
		
		
		if (HotelGuestsApp_Loginpage.textfieldUsername.getText().equals("") || HotelGuestsApp_Loginpage.passwordField.getText().equals("")) {
			HotelGuestsApp_Loginpage.labelOutput.setText("Please fill in all fields.");
		}
		
		else {
			String sql = "SELECT * FROM users WHERE UserId='" + HotelGuestsApp_Loginpage.textfieldUsername.getText() + "'";
			ResultSet rs = DBUtil.getTable(sql);
			
			try {
				int counter = 0;
				while (rs.next()) {
					counter++;
					String userId = rs.getString("UserId");
					String name = rs.getString("UserName");
					String userPassword = rs.getString("Password");
					
					if ((userId.equals(HotelGuestsApp_Loginpage.textfieldUsername.getText()) && userPassword.equals(HotelGuestsApp_Loginpage.passwordField.getText())) && (userId.equals(HotelGuestsApp_Loginpage.textfieldUsername.getText()) && userPassword.equals(HotelGuestsApp_Loginpage.unstarPasswordField.getText()))) {
						HotelGuestsApp_Loginpage.labelOutput.setText("Logging in...");
						Stage stage = (Stage) HotelGuestsApp_Loginpage.buttonLogin.getScene().getWindow();
					    stage.close();
						
						labelTitle.setFont(Font.font("Brush Script MT",FontWeight.BOLD,50));
						labelTitle.setTextFill(Color.BROWN);
						labelWelcome.setText("Welcome, " + name + "!");
						labelWelcome.setFont(Font.font("Arial",FontWeight.BOLD,18));
						labelWelcome.setTextFill(Color.BLUE);
						
						btnAddGuest.setPrefWidth(BUTTON_PREFWIDTH);
						btnUpdateBookings.setPrefWidth(BUTTON_PREFWIDTH);
						btnDeleteBookings.setPrefWidth(BUTTON_PREFWIDTH);
						btnViewGuestDetails.setPrefWidth(BUTTON_PREFWIDTH);
						btnAddBookings.setPrefWidth(BUTTON_PREFWIDTH);
					
						btnAddGuest.setFont(Font.font("Arial",FontWeight.BOLD,12));
						btnAddGuest.setTextFill(Color.WHITE);
						btnAddGuest.setStyle("-fx-background-color: BLUE");
						
						btnUpdateBookings.setFont(Font.font("Arial",FontWeight.BOLD,12));
						btnUpdateBookings.setTextFill(Color.WHITE);
						btnUpdateBookings.setStyle("-fx-background-color: BLUE");
						
						btnDeleteBookings.setFont(Font.font("Arial",FontWeight.BOLD,12));
						btnDeleteBookings.setTextFill(Color.WHITE);
						btnDeleteBookings.setStyle("-fx-background-color: BLUE");
						
						btnViewGuestDetails.setFont(Font.font("Arial",FontWeight.BOLD,12));
						btnViewGuestDetails.setTextFill(Color.WHITE);
						btnViewGuestDetails.setStyle("-fx-background-color: BLUE");
						
						btnAddBookings.setFont(Font.font("Arial",FontWeight.BOLD,12));
						btnAddBookings.setTextFill(Color.WHITE);
						btnAddBookings.setStyle("-fx-background-color: BLUE");

						EventHandler<ActionEvent> handler1 = (ActionEvent e) -> (new HotelGuestsApp_AddGuest()).start(new Stage());
						btnAddGuest.setOnAction(handler1);
						
						EventHandler<ActionEvent> handler2 = (ActionEvent e) -> (new HotelGuestsApp_UpdateBookings()).start(new Stage());
						btnUpdateBookings.setOnAction(handler2);
						
						EventHandler<ActionEvent> handler3 = (ActionEvent e) -> (new HotelGuestsApp_DeleteBookings()).start(new Stage());
						btnDeleteBookings.setOnAction(handler3);
						
						EventHandler<ActionEvent> handler4 = (ActionEvent e) -> (new HotelGuestsApp_ViewGuestDetails()).start(new Stage());
						btnViewGuestDetails.setOnAction(handler4);
						
						EventHandler<ActionEvent> handler5 = (ActionEvent e) -> (new HotelGuestsApp_AddBookings()).start(new Stage());
						btnAddBookings.setOnAction(handler5);
						
						VBox pane = new VBox();
						pane.setAlignment(Pos.CENTER);
						pane.setPadding(new Insets(10,10,10,10));
						pane.setSpacing(15);
						pane.getChildren().addAll(labelTitle, labelWelcome, labelChoose, btnAddGuest, btnAddBookings, btnUpdateBookings, btnDeleteBookings, btnViewGuestDetails);
						
						Scene mainScene = new Scene(pane);
						
						primaryStage.setTitle("Main Menu");
						primaryStage.setWidth(300);
						primaryStage.setHeight(500);
						primaryStage.setScene(mainScene);
						primaryStage.show();
						
					}
					
					else {
						HotelGuestsApp_Loginpage.labelOutput.setText("Incorrect username or password.");
					}
				}
				if (counter == rs.getRow()) {
					HotelGuestsApp_Loginpage.labelOutput.setText("Incorrect username or password.");
				}
				DBUtil.close();
			}
			
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
}
