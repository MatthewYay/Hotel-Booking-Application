/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 28, 2021 9:32:29 PM
 */

package c209_gradedPart2.Final;

public class SHNGuest extends Guest {

	private String travelDocType;

	public SHNGuest(int bookingId, int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice,
			int contactNumber, int noOfDays, String travelDocType) {
		super(bookingId, guestId, guestName, guestRoomNo, guestType, dailyPrice, contactNumber, noOfDays);
		this.travelDocType = travelDocType;
	}

	public String getTravelDocType() {
		return travelDocType;
	}

	public double calculateHotelStayFee(int dailyPrice) {
		double cost = noOfDays * dailyPrice;
		return cost;
	}
}
