/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Aug 3, 2021 8:51:41 AM
 */

package c209_gradedPart2.Final;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.beans.value.ChangeListener;

public class HotelGuestsApp_AddBookings extends Application {

	private VBox vPane = new VBox();
	private VBox radioVPane = new VBox();
	private ToggleGroup tg = new ToggleGroup();
	private Label lbRadioBtChoice = new Label("Choose a guest type: ");
    private RadioButton r1 = new RadioButton("Stay-home-notice Guest");
    private RadioButton r2 = new RadioButton("Staycation Guest");
    private Label labelRadioButtonChosen = new Label();
	private HBox hPane1 = new HBox();
	private HBox hPane2 = new HBox();
	private HBox hPane3 = new HBox();
	private HBox hPane4 = new HBox();
	private HBox hPane5 = new HBox();
	private HBox hPane6 = new HBox();
	private HBox hPane7 = new HBox();
	private HBox hPane8 = new HBox();
	private Label labelGuestID = new Label("Guest ID:");
	private Label labelRoomNo = new Label("Room Number:");
	private Label labelGuestType = new Label("Guest Type:");
	private Label labelDiscountCode = new Label("Discount Code:");
	private Label labelGroupSize = new Label("Group Size:");
	private TextField textfieldGroupSize = new TextField();
	private Label lbCheckInDate = new Label("Check-in Date: ");
	private DatePicker tfCheckInDate = new DatePicker();
	private Label lbCheckOutDate = new Label("Check-out Date: ");
	private DatePicker tfCheckOutDate = new DatePicker();
	private Label lbOutput = new Label();
	private Button btAdd = new Button("Add");
	private Label labelCheckInDate = new Label();
	private Label labelCheckOutDate = new Label();
	private static final String patternForSTCGroupSize = "\\d+";
	private static final String JDBC_URL = "jdbc:mysql://localhost:3310/c209_ga_final"; //I am using Port 3310, not 3308
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "";
	private static final int LABEL_PREFWIDTH = 90;
	private static final int TEXTFIELD_COLUMNCOUNT = 15;
	private Label lbSelectedGuestID = new Label();
	private Label lbSelectedRoomNo = new Label();
	private Label lbSelectedDiscountCode = new Label();
	private int positioning = 0;
	
	public void start(Stage primaryStage) {
		
		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);
		
		ArrayList<String> guestIDList = new ArrayList<String>();
		ResultSet rs1 = DBUtil.getTable("SELECT GuestID FROM guests");
		try {
			while(rs1.next()) {
				int guestId = rs1.getInt("GuestID");
				guestIDList.add(String.valueOf(guestId));
			}
		}
		catch (SQLException e) {
			e.getMessage();
		}
		
		ComboBox cbGuestID = new ComboBox(FXCollections.observableArrayList(guestIDList));
		EventHandler<ActionEvent> event1 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e1)
            {
                lbSelectedGuestID.setText(cbGuestID.getValue() + "");
            }
        };
        cbGuestID.setOnAction(event1);
        
    	ArrayList<String> roomNoList = new ArrayList<String>();
		rs1 = DBUtil.getTable("SELECT RoomNo FROM hotel_room");
		try {
			while(rs1.next()) {
				String roomNo = rs1.getString("RoomNo");
				roomNoList.add(roomNo);
			}
		}
		catch (SQLException e) {
			e.getMessage();
		}
		
		ComboBox cbRoomNo = new ComboBox(FXCollections.observableArrayList(roomNoList));
		EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e2)
            {
                lbSelectedRoomNo.setText(cbRoomNo.getValue() + "");
            }
        };
        cbRoomNo.setOnAction(event2);
		
        ArrayList<String> discountCodeList = new ArrayList<String>();
		rs1 = DBUtil.getTable("SELECT DiscountCode FROM hotel_discounts");
		try {
			while(rs1.next()) {
				String discountCode = rs1.getString("DiscountCode");
				discountCodeList.add(discountCode);
			}
		}
		catch (SQLException e) {
			e.getMessage();
		}
		
		ComboBox cbDiscountCode = new ComboBox(FXCollections.observableArrayList(discountCodeList));
        EventHandler<ActionEvent> event4 = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e4)
            {
                lbSelectedDiscountCode.setText(cbDiscountCode.getValue() + "");
            }
        };
        cbDiscountCode.setOnAction(event4);
		
        
        
		btAdd.setFont(Font.font("Arial",FontWeight.BOLD,12));
		btAdd.setTextFill(Color.WHITE);
		btAdd.setStyle("-fx-background-color: BLUE");
		
		labelGuestID.setPrefWidth(LABEL_PREFWIDTH);
		labelRoomNo.setPrefWidth(LABEL_PREFWIDTH);
		labelGuestType.setPrefWidth(LABEL_PREFWIDTH);
		labelDiscountCode.setPrefWidth(LABEL_PREFWIDTH);
		labelGroupSize.setPrefWidth(LABEL_PREFWIDTH);
		textfieldGroupSize.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		lbCheckInDate.setPrefWidth(LABEL_PREFWIDTH);
		lbCheckOutDate.setPrefWidth(LABEL_PREFWIDTH);
		
		cbGuestID.setDisable(true);
		cbRoomNo.setDisable(true);
		cbDiscountCode.setDisable(true);
		textfieldGroupSize.setEditable(false);
		tfCheckInDate.setDisable(true);
		tfCheckOutDate.setDisable(true);
		btAdd.setDisable(true);
		
		EventHandler<ActionEvent> handleAdd = (ActionEvent e) -> doAddBooking();
		btAdd.setOnAction(handleAdd);
		
		EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                LocalDate i = tfCheckInDate.getValue();
                labelCheckInDate.setText(i.toString());
            }
        };
        tfCheckInDate.setShowWeekNumbers(true);
        tfCheckInDate.setOnAction(event);
        
        EventHandler<ActionEvent> eventTwo = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e)
            {
                LocalDate ld = tfCheckOutDate.getValue();
                labelCheckOutDate.setText(ld.toString());
            }
        };
        tfCheckOutDate.setShowWeekNumbers(true);
        tfCheckOutDate.setOnAction(eventTwo);
		
        labelRadioButtonChosen.setFont(Font.font("Arial",FontWeight.BOLD,12));
        labelRadioButtonChosen.setTextFill(Color.RED);
        r1.setToggleGroup(tg);
        r2.setToggleGroup(tg);
		radioVPane.getChildren().addAll(lbRadioBtChoice, r1, r2);
		radioVPane.setAlignment(Pos.CENTER);
		radioVPane.setSpacing(10);
		hPane1.getChildren().addAll(labelGuestID, cbGuestID);
		hPane1.setAlignment(Pos.CENTER);
		hPane2.getChildren().addAll(labelRoomNo, cbRoomNo);
		hPane2.setAlignment(Pos.CENTER);
		hPane3.getChildren().addAll(labelDiscountCode, cbDiscountCode);
		hPane3.setAlignment(Pos.CENTER);
		hPane4.getChildren().addAll(labelGroupSize, textfieldGroupSize);
		hPane4.setAlignment(Pos.CENTER);
		hPane5.getChildren().addAll(lbCheckInDate, tfCheckInDate);
		hPane5.setAlignment(Pos.CENTER);
		hPane6.getChildren().addAll(lbCheckOutDate, tfCheckOutDate);
		hPane6.setAlignment(Pos.CENTER);
		hPane7.getChildren().add(btAdd);
		hPane7.setAlignment(Pos.CENTER);
		hPane8.getChildren().add(lbOutput);
		hPane8.setAlignment(Pos.CENTER);
		vPane.getChildren().addAll(radioVPane, labelRadioButtonChosen, hPane1, hPane2, hPane3, hPane4, hPane5, hPane6, hPane7, hPane8);
		
		tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>() 
        {
            public void changed(ObservableValue<? extends Toggle> ob, 
                                                    Toggle o, Toggle n)
            {
  
                RadioButton rb = (RadioButton)tg.getSelectedToggle();
  
                if (rb != null) {
                    String s = rb.getText();
                    if (s.equals("Staycation Guest")) {
                    	cbGuestID.setDisable(false);
                		cbRoomNo.setDisable(false);
                		cbDiscountCode.setDisable(false);
                		textfieldGroupSize.setEditable(true);
                		tfCheckInDate.setDisable(false);
                		tfCheckOutDate.setDisable(false);
                		btAdd.setDisable(false);
                		labelRadioButtonChosen.setText("Staycation Guest Chosen. You need to fill in all fields.");
                    }
                    else if (s.equals("Stay-home-notice Guest")) {
                    	cbGuestID.setDisable(false);
                		cbRoomNo.setDisable(false);
                		cbDiscountCode.setDisable(true);
                		textfieldGroupSize.setEditable(false);
                		tfCheckInDate.setDisable(false);
                		tfCheckOutDate.setDisable(false);
                		btAdd.setDisable(false);
                		labelRadioButtonChosen.setText("Stay-home-notice Guest Chosen. You need to fill in all fields except 'discount code' and 'group size'.");
                    }
                }
            }
        });
		
		vPane.setAlignment(Pos.CENTER);
		vPane.setSpacing(10);
		
		vPane.setAlignment(Pos.CENTER);
		vPane.setSpacing(10);
		
		BorderPane.setAlignment(vPane, Pos.CENTER);
		
		vPane.setPadding(new Insets(10,10,10,10));
		Scene mainScene = new Scene(vPane);
		
		primaryStage.setTitle("Add Room Booking");
		primaryStage.setWidth(700);
		primaryStage.setHeight(480);
		primaryStage.setScene(mainScene);
		primaryStage.show();

	}

	public void doAddBooking() {

		DBUtil.init(JDBC_URL, DB_USERNAME, DB_PASSWORD);
		ResultSet rs = DBUtil.getTable("SELECT * FROM hotel_bookings");
		try {
			while(rs.next()) {
			}
			rs.last();
			positioning = rs.getRow();
		}
		catch(SQLException e) {
			e.getMessage();
		}
		
		if (labelRadioButtonChosen.getText().equals("Staycation Guest Chosen. You need to fill in all fields.")){
			if (!Pattern.matches(patternForSTCGroupSize, textfieldGroupSize.getText())) {
				lbOutput.setText("Invalid group size, please give a numeric input!");
			}
			else if (lbSelectedGuestID.getText().equals("") || lbSelectedRoomNo.getText().equals("") || lbSelectedDiscountCode.getText().equals("") || textfieldGroupSize.getText().equals("") || labelCheckOutDate.getText().equals("") || labelCheckInDate.getText().equals("")) {
				lbOutput.setText("Please fill in all fields.");
			}
			else {
				String addSTCSQL = String.format("INSERT INTO hotel_bookings (BookingID,GuestID,RoomNo,GuestType,DiscountCode,GroupSize,CheckIn,CheckOut) VALUES ('%d','%d','%s','%s','%s','%d','%s','%s')", positioning+1, Integer.parseInt(lbSelectedGuestID.getText()), lbSelectedRoomNo.getText(), "STC", lbSelectedDiscountCode.getText(), Integer.parseInt(textfieldGroupSize.getText()), labelCheckInDate.getText(), labelCheckOutDate.getText());
				int rowsUpdated = DBUtil.execSQL(addSTCSQL);

				if (rowsUpdated == 1) {
					lbOutput.setText("New STC guest booking successfully added!");
				} else {
					lbOutput.setText("Adding of STC guest failed!");
				}
			}
		}
		
		
		else if (labelRadioButtonChosen.getText().equals("Stay-home-notice Guest Chosen. You need to fill in all fields except 'discount code' and 'group size'.")) {
			if (lbSelectedGuestID.getText().equals("") || lbSelectedRoomNo.getText().equals("") || labelCheckOutDate.getText().equals("") || labelCheckInDate.getText().equals("")) {
				lbOutput.setText("Please fill in all fields.");
			}
			else {
				String addSHNSQL = String.format("INSERT INTO hotel_bookings (BookingID,GuestID,RoomNo,GuestType,DiscountCode,GroupSize,CheckIn,CheckOut) VALUES ('%d','%d','%s','%s','%s',null,'%s','%s')", positioning+1, Integer.parseInt(lbSelectedGuestID.getText()), lbSelectedRoomNo.getText(), "SHN", "", labelCheckInDate.getText(), labelCheckOutDate.getText());
				int rowsUpdated = DBUtil.execSQL(addSHNSQL);

				if (rowsUpdated == 1) {
					lbOutput.setText("New SHN guest booking successfully added!");
				} else {
					lbOutput.setText("Adding of SHN guest failed!");
				}
			}
		}
		DBUtil.close();
	}

}
