/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 29, 2021 10:09:27 PM
 */

package c209_gradedPart2.Final;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class HotelGuestsApp_Loginpage extends Application{

	private VBox pane = new VBox();
	private HBox secondPane = new HBox();
	private HBox row1 = new HBox();
	private HBox row2 = new HBox();
	private HBox row3 = new HBox();
	private HBox row4 = new HBox();
	private HBox passwordRow = new HBox();
	private Label labelTitle1 = new Label("Kingston Hotel");
	private Label labelTitle2 = new Label("Sign in with your organizational account\n\n");
	private Label labelUsername = new Label("Username: ");
	private Label labelPassword = new Label("Password: ");
	protected static Label labelOutput = new Label();
	protected static TextField textfieldUsername = new TextField();
	protected static PasswordField passwordField = new PasswordField();
	protected static TextField unstarPasswordField = new TextField();
	private Button buttonShow = new Button("Show/Hide Password");
	protected static Button buttonLogin = new Button("Sign In");
	private static final int LABEL_PREFWIDTH = 70;
	private static final int TEXTFIELD_COLUMNCOUNT = 15;
	protected static boolean checker = false;

	public static void main(String[] args) {
		launch(args);
	}
	
	public void start(Stage primaryStage) throws Exception {
		
		Image photo = new Image("file:C209ese_Hotel_Pic.JPG");
		ImageView photoDisplayed = new ImageView(photo);
		photoDisplayed.setFitWidth(450);
		photoDisplayed.setFitHeight(230);
		secondPane.getChildren().addAll(photoDisplayed);
		
		labelUsername.setPrefWidth(LABEL_PREFWIDTH);
		labelPassword.setPrefWidth(LABEL_PREFWIDTH);
		textfieldUsername.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		passwordField.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		unstarPasswordField.setPrefColumnCount(TEXTFIELD_COLUMNCOUNT);
		
		labelTitle1.setFont(Font.font("Brush Script MT",FontWeight.BOLD,50));
		labelTitle1.setTextFill(Color.BROWN);

		buttonLogin.setFont(Font.font("Arial",FontWeight.BOLD,12));
		buttonLogin.setTextFill(Color.WHITE);
		buttonLogin.setStyle("-fx-background-color: BLUE");
		
		EventHandler<ActionEvent> handleLoginButton = (ActionEvent e) -> {
			try {
				(new HotelGuestsApp_MainMenu()).start(new Stage());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		};
		
		buttonLogin.setOnAction(handleLoginButton);
		
		row1.getChildren().addAll(labelTitle1);
		row1.setAlignment(Pos.CENTER);
		row2.getChildren().addAll(labelTitle2);
		row3.getChildren().addAll(labelUsername,textfieldUsername);
		passwordRow.getChildren().addAll(passwordField,buttonShow);
		passwordRow.setSpacing(10);
		row4.getChildren().addAll(labelPassword, passwordRow);
		
		buttonShow.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent event) {
				
				if (checker == false) {
					unstarPasswordField.setText(passwordField.getText());
					passwordRow.getChildren().clear();
					passwordRow.getChildren().addAll(unstarPasswordField,buttonShow);
					checker = true;
				}
				else {
					passwordField.setText(unstarPasswordField.getText());
					passwordRow.getChildren().clear();
					passwordRow.getChildren().addAll(passwordField,buttonShow);
					checker = false;
				}
			}
			
		});
		
		
		pane.getChildren().addAll(row1,secondPane,row2,row3,row4,buttonLogin,labelOutput);
		pane.setAlignment(Pos.TOP_CENTER);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setSpacing(10);
		Scene mainScene = new Scene(pane);
		
		primaryStage.setTitle("Login");
		primaryStage.setWidth(450);
		primaryStage.setHeight(580);
		primaryStage.setScene(mainScene);
		primaryStage.show();
		
	}
	
}
