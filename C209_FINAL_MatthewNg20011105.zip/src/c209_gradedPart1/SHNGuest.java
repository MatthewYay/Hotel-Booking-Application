/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 2, 2021 1:42:09 PM
 */

package c209_gradedPart1;

public class SHNGuest extends Guest {

	private int noOfShnDays;
	private String travelDocType;

	public SHNGuest(int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice,
			int noOfShnDays, String travelDocType) {
		super(guestId, guestName, guestRoomNo, guestType, dailyPrice);
		this.noOfShnDays = noOfShnDays;
		this.travelDocType = travelDocType;
	}

	public int getNoOfShnDays() {
		return noOfShnDays;
	}

	public String getTravelDocType() {
		return travelDocType;
	}
	
	public void display() {
		super.display();
		System.out.println("Number of Stay-Home-Notice (SHN) days: " + noOfShnDays);
		System.out.println("Type of Travel Document: " + travelDocType);
	}
	
	public double calculateHotelStayFee(int dailyPrice) {
		//My own enhancement
		double cost = noOfShnDays * dailyPrice;
		return cost;
	}
}
