/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 2, 2021 2:05:33 PM
 */

package c209_gradedPart1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class HotelGuestsApp {

	private Connection conn;
	private Statement statement;
	private ResultSet rs;
	private ArrayList<Guest> guestsList = new ArrayList<Guest>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HotelGuestsApp hga = new HotelGuestsApp();
		hga.start();
	}
	
	private void start() {

		try {
			String connectionString = "jdbc:mysql://localhost:3310/c209_gradedassignment"; //I am using port 3310, not port 3306
			String userId = "root";
			String remoteDbPassword = "";

			conn = DriverManager.getConnection(connectionString, userId, remoteDbPassword);
			statement = conn.createStatement();
			
			loadGuests();
			int option = -1;
	
			while (option != 5) {
				menu();
				option = Helper.readInt("Enter choice > ");
	
				if (option == 1) {
					viewAllGuests();
				} else if (option == 2) {
					viewStaycationGuests();
				} else if (option == 3) {
					viewShnGuests();
				} else if (option == 4) {
					viewAllGuestsHotelStayFee(); //My own enhancement
				} else if (option == 5) {
	
					rs.close();
					statement.close();
					conn.close();
	
					System.out.println("Thank you for using Hotel Guests App, goodbye!");
				} else {
					System.out.println("Invalid choice!");
				}
			}
		}
		catch (SQLException se){
			System.out.println("Error: " + se.getMessage());
			se.printStackTrace();
		}
	}
	
	private void menu() {
		System.out.println("");
		Helper.line(120, "=");
		System.out.println("HOTEL GUEST APP");
		Helper.line(120, "=");
		System.out.println("1. View All Guests");
		System.out.println("2. View Staycation Guests");
		System.out.println("3. View SHN Guests");
		System.out.println("4. View All Guests' Hotel Stay Fee"); //My own enhancement
		System.out.println("5. Quit");
	}
	
	private void loadGuests(){
		try {
			rs = statement.executeQuery("SELECT hg.*, hr.*, hd.*, td.* FROM hotel_guests hg LEFT JOIN hotel_room hr ON hg.RoomNo = hr.RoomNo LEFT JOIN hotel_discounts hd ON hg.DiscountCode = hd.DiscountCode LEFT JOIN travel_docs td ON hg.TravelDocID = td.ID");
			
			while (rs.next()) {
				int guestId = rs.getInt("hg.ID");
				String guestName = rs.getString("hg.Name");
				String guestRoomNo = rs.getString("hg.RoomNo");
				String guestType = rs.getString("hg.GuestType");
				String discountCode = rs.getString("hg.DiscountCode");
				int groupSize = rs.getInt("hg.GroupSize");
				int noOfShnDays = rs.getInt("hg.SHNdays");
				String travelDocType = rs.getString("td.Description");
				int dailyPrice = rs.getInt("hr.DailyPrice");
				int noOfStcDays = rs.getInt("hg.STCdays");
				int discountRate = rs.getInt("hd.Rate");
				String discountType = rs.getString("hd.DiscountType");
				
				if (guestType.equals("SHN")) {
					Guest newShnGuest = new SHNGuest(guestId, guestName, guestRoomNo, guestType, dailyPrice, noOfShnDays, travelDocType);
					guestsList.add(newShnGuest);
				}
				
				else if(guestType.equals("STC")) {
					Guest newStcGuest = new STCGuest(guestId, guestName, guestRoomNo, guestType, dailyPrice, discountCode, groupSize, noOfStcDays, discountRate, discountType);
					guestsList.add(newStcGuest);
				}
				
			}

		} catch (SQLException se) {
			System.out.println("Error: " + se.getMessage());
			se.printStackTrace();
		}
	}

	private void viewAllGuests() {

		Helper.line(120, "-");
		System.out.println("ALL GUESTS:");
		Helper.line(11, "-");
		System.out.println("");
		
		for (Guest g : guestsList) {
			System.out.println("Guest Registration ID: " + g.getGuestId());
			System.out.println("Guest Name: " + g.getGuestName());
			System.out.println("Room Number: " + g.getGuestRoomNo());
			System.out.println(String.format("Guest Type: %s\n", g.getGuestType()));
		}
		
	}

	private void viewStaycationGuests() {

		Helper.line(120, "-");
		System.out.println("ALL STAYCATION GUESTS:");
		Helper.line(22, "-");
		
		for (Guest g : guestsList) {
			if (g instanceof STCGuest) {
				g.display();
			}
		}
		
	}
	
	private void viewShnGuests() {

		Helper.line(120, "-");
		System.out.println("ALL STAY-HOME-NOTICE (SHN) GUESTS:");
		Helper.line(34, "-");
		
		for (Guest g : guestsList) {
			if (g instanceof SHNGuest) {
				g.display();
			}
		}
	}
	
	private void viewAllGuestsHotelStayFee() {
		
		Helper.line(120, "-");
		System.out.println("HOTEL STAY FEE OF ALL GUESTS:");
		Helper.line(29, "-");
		
		for (Guest g : guestsList) {
			if (g instanceof STCGuest) {
				g.display();
				System.out.println(String.format("Total Hotel Stay Fee: $%.2f", g.calculateHotelStayFee(g.getDailyPrice())));
			}
			else if (g instanceof SHNGuest) {
				g.display();
				System.out.println(String.format("Total Hotel Stay Fee: $%.2f", g.calculateHotelStayFee(g.getDailyPrice())));
			}
		}
	}
}
