/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 2, 2021 1:41:55 PM
 */

package c209_gradedPart1;

public class STCGuest extends Guest{

	private String discountCode;
	private int groupSize;
	private int noOfStcDays;
	private int discountRate;
	private String discountType;

	public STCGuest(int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice,
			String discountCode, int groupSize, int noOfStcDays, int discountRate, String discountType) {
		super(guestId, guestName, guestRoomNo, guestType, dailyPrice);
		this.discountCode = discountCode;
		this.groupSize = groupSize;
		this.noOfStcDays = noOfStcDays;
		this.discountRate = discountRate;
		this.discountType = discountType;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public int getGroupSize() {
		return groupSize;
	}

	public int getNoOfStcDays() {
		return noOfStcDays;
	}

	public int getDiscountRate() {
		return discountRate;
	}

	public String getDiscountType() {
		return discountType;
	}

	public void display() {
		super.display();
		System.out.println("Discount Code: " + discountCode);
		System.out.println("Group Size: " + groupSize);
	}
	
	public double calculateHotelStayFee(int dailyPrice) {
		//My own enhancement
		double cost = 0;
		if (discountType.equals("Fixed")) {
			cost = (dailyPrice * noOfStcDays) - (discountRate * noOfStcDays);
		}
		else if (discountType.equals("Percentage")) {
			cost = (dailyPrice * noOfStcDays) * ((100.00 - discountRate)/100.00);
		}
		return cost;
	}
}
