/*
 * I declare that this code was written by me. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Matthew Ng Wei Chen 20011105, Jul 2, 2021 1:44:34 PM
 */

package c209_gradedPart1;

public abstract class Guest {

	private int guestId;
	private String guestName;
	private String guestRoomNo;
	private String guestType;
	private int dailyPrice;

	public Guest(int guestId, String guestName, String guestRoomNo, String guestType, int dailyPrice) {
		this.guestId = guestId;
		this.guestName = guestName;
		this.guestRoomNo = guestRoomNo;
		this.guestType = guestType;
		this.dailyPrice = dailyPrice;
	}

	public int getGuestId() {
		return guestId;
	}

	public String getGuestName() {
		return guestName;
	}

	public String getGuestRoomNo() {
		return guestRoomNo;
	}

	public String getGuestType() {
		return guestType;
	}

	public int getDailyPrice() {
		return dailyPrice;
	}

	public void display() {
		System.out.println("");
		System.out.println("Guest Registration ID: " + guestId);
		System.out.println("Guest Name: " + guestName);
		System.out.println("Room Number: " + guestRoomNo);
		System.out.println("Guest Type: " + guestType);
	}
	
	public abstract double calculateHotelStayFee(int dailyPrice); //My own enhancement
}
